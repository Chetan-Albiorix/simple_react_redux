export enum RecordTypeEnum {
    All,
    Starred,
    Trashed
}